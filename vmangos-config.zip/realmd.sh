#!/bin/bash
# Reamld服务启动文件 (使用screen方式)

# 加载配置
Load_profile() {
    Service_Config="/VMaNGOS/etc/realmd.conf"
    Service_File="/VMaNGOS/bin/realmd"
    Service_Name="realmd"
    Screen_Name="realmd_screen"  # screen会话名称
}

# 检查screen是否安装
Check_screen() {
    if ! command -v screen &> /dev/null; then
        echo "Error: screen is not installed. Please install it first:"
        echo "sudo apt-get install screen"
        return 1
    fi
}

# 启动服务
Start_Service() {
    Load_profile
    Check_screen
    
    # 检查二进制文件是否存在
    if [ ! -f "$Service_File" ]; then
        echo "$Service_Name Binary file does not exist，Please check if the path is correct ($Service_File)"
        return 1
    fi
    
    # 检查是否已在运行
    Check_Service_PID=`pgrep -f "^$Service_File -c $Service_Config$"`
    if [[ -n ${Check_Service_PID} ]]; then
        echo "$Service_Name is already running"
	else
		echo "$Service_Name Started....."
		# 使用screen启动
		screen -dmS $Screen_Name ${Service_File} -c ${Service_Config}
    fi
    
    return 0
}

# 停止服务
Stop_Service() {
    Load_profile
    
    # 获取PID
    Check_Service_PID=`pgrep -f "^$Service_File -c $Service_Config$"`
    
    if [[ -z ${Check_Service_PID} ]]; then
        echo "$Service_Name is not running"
	else
		# 停止服务
		echo "$Service_Name Stopped....."
		kill -15 $Check_Service_PID
		
		# 等待进程结束
		for i in {1..10}; do
			if ps -p $Check_Service_PID > /dev/null; then
				sleep 1
			else
				break
			fi
		done
		
		# 强制杀死如果仍然运行
		if ps -p $Check_Service_PID > /dev/null; then
			echo "$Service_Name Force killing...."
			kill -9 $Check_Service_PID
		fi
		
		# 清理screen会话
		screen -S $Screen_Name -X quit >/dev/null 2>&1
    fi
	
    return 0
}

# 重启服务
Restart_Service() {
    Stop_Service
    Start_Service
    exit 0
}

# 检查服务状态
Check_Service_Run() {
    Load_profile
    
    printf "%-70s" "$Service_Name Status"
    Check_Service_PID=`pgrep -f "^$Service_File -c $Service_Config$"`
    if [[ -n ${Check_Service_PID} ]]; then
		echo -e "[ \033[32m Running \033[0m ]"
    else
        echo -e "[ \033[31m Not running \033[0m ]"
    fi
    
    exit 0
}

case $1 in
    "start")
        Start_Service
    ;;
    "restart")
        Restart_Service
    ;;
    "stop")
        Stop_Service
    ;;    
    "status"|"state")
        Check_Service_Run
    ;;
    "attach")
        Load_profile
        echo "Attaching to screen session '$Screen_Name'..."
        screen -r $Screen_Name
        exit 0
    ;;
    *) 
        echo "Usage: $0 [start|restart|stop|status|state|attach]"
        echo "Example:"
        echo "  Start service:    $0 start"
        echo "  Restart service:  $0 restart"
        echo "  Stop service:     $0 stop"
        echo "  Check status:     $0 status"
        echo "  Attach to screen: $0 attach"
        exit 1
    ;;
esac
