#!/bin/bash
#Realmd服务启动文件


Start_Service()
{
	Load_profile
	
	
	#启动
	if [ ! -f "$Service_File" ]; then
		#失败
		echo "$Service_Name Binary file does not exist，Please check if the path is correct ($Service_File)";
		exit 1;
		#mkdir /Super
	else
		#启动
		${Service_File} -c ${Service_Config} -s run >/dev/null 2>&1
		Check_Service_PID=`ps -ef |grep "$Service_Name" |grep -v "grep" |awk '{print $2}'`;
		if [[ ! -z ${Check_Service_PID} ]]; then
			echo "$Service_Name Started....."
		else
			echo "$Service_Name Fail to start.....";
			exit 1;
		fi
	fi
	
	
	
	exit 0;
	
}

Stop_Service()
{
	Load_profile
	
	
	
	#停止
	${Service_File} -c ${Service_Config} -s stop >/dev/null 2>&1
	echo "$Service_Name Stopped....."
	
	
	exit 0;
	
	
	
	
	
}

Restart_Service()
{
	Load_profile
	
	#启动
	if [ ! -f "$Service_File" ]; then
		#失败
		echo "$Service_Name Binary file does not exist，Please check if the path is correct ($Service_File)";
		exit 1;
	else
		#停止
		${Service_File} -c ${Service_Config} -s stop >/dev/null 2>&1
		echo "$Service_Name Stopped....."
		#启动
		${Service_File} -c ${Service_Config} -s run >/dev/null 2>&1
		Check_Service_PID=`ps -ef |grep "$Service_Name" |grep -v "grep" |awk '{print $2}'`;
		if [[ ! -z ${Check_Service_PID} ]]; then
			echo "$Service_Name Started....."
		else
			echo "$Service_Name Fail to start.....";
			exit 1;
		fi
	fi
	
	
	exit 0;
	
}


Check_Service_Run()
{
	
	Load_profile
	
	printf "%-70s"  "$Service_Name PID"
	Check_Service_PID=`ps -ef |grep "$Service_Name" |grep -v "grep" |awk '{print $2}'`;
	if [[ ! -z ${Check_Service_PID} ]]; then
		echo -e "[ \033[32m Running \033[0m ]"
	else
		echo -e "[ \033[31m Not running \033[0m ]"
	fi
	
	exit 0;
	
}

Load_profile()
{
	Service_Config="/folder/mangos/etc/realmd.conf";
	Service_File="/folder/mangos/bin/realmd";
	Service_Name="realmd";
	
}



case $1 in
	"start")
		Start_Service
	;;
	"restart")
		Restart_Service
	;;
	"stop")
		Stop_Service
	;;	
	"status")
		Check_Service_Run
	;;
	"state")
		Check_Service_Run
	;;
	
	*) 
		echo "Please execute the following command $0 [start|restart|stop|status|state] For example, restart $0 service command $0 restart";
		exit 0;
    ;;
esac 


