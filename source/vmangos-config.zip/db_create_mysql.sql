/*
创建vmangos表
*/
CREATE DATABASE `mangos` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE DATABASE `logs` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE DATABASE `characters` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE DATABASE `realmd` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

/*
设置所有位置登录权限
*/
CREATE USER 'mangos'@'%' IDENTIFIED BY 'mangospassword';
/*
设置localhost位置登录权限
*/
CREATE USER 'mangos'@'localhost' IDENTIFIED BY 'mangospassword';
/*
设置127.0.0.1位置登录权限
*/
CREATE USER 'mangos'@'127.0.0.1' IDENTIFIED BY 'mangospassword';

/*
设置所有位置访问权限
*/
GRANT ALL PRIVILEGES ON `mangos`.* TO 'mangos'@'%';
GRANT ALL PRIVILEGES ON `logs`.* TO 'mangos'@'%';
GRANT ALL PRIVILEGES ON `characters`.* TO 'mangos'@'%';
GRANT ALL PRIVILEGES ON `realmd`.* TO 'mangos'@'%';
/*
设置localhost位置访问权限
*/
GRANT ALL PRIVILEGES ON `mangos`.* TO 'mangos'@'localhost';
GRANT ALL PRIVILEGES ON `logs`.* TO 'mangos'@'localhost';
GRANT ALL PRIVILEGES ON `characters`.* TO 'mangos'@'localhost';
GRANT ALL PRIVILEGES ON `realmd`.* TO 'mangos'@'localhost';

/*
设置127.0.0.1位置访问权限
*/
GRANT ALL PRIVILEGES ON `mangos`.* TO 'mangos'@'127.0.0.1';
GRANT ALL PRIVILEGES ON `logs`.* TO 'mangos'@'127.0.0.1';
GRANT ALL PRIVILEGES ON `characters`.* TO 'mangos'@'127.0.0.1';
GRANT ALL PRIVILEGES ON `realmd`.* TO 'mangos'@'127.0.0.1';

/*
刷新列表 立即生效
*/
FLUSH PRIVILEGES;


