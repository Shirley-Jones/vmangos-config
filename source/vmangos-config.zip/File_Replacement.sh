#!/bin/bash
File=$0
INSTALL_DIR=$1
INSTALL_DIR_TEXT=$(echo "$INSTALL_DIR" | sed "s/\\//\\\\&/g")


rm -rf $INSTALL_DIR/mangos/etc/mangosd.conf
rm -rf $INSTALL_DIR/mangos/etc/realmd.conf
mv $INSTALL_DIR/mangos/mangosd.conf $INSTALL_DIR/mangos/etc/mangosd.conf
mv $INSTALL_DIR/mangos/realmd.conf $INSTALL_DIR/mangos/etc/realmd.conf
mv $INSTALL_DIR/mangos/Mangosd_Controller.sh $INSTALL_DIR/mangos/bin/Mangosd_Controller.sh
mv $INSTALL_DIR/mangos/Realmd_Controller.sh $INSTALL_DIR/mangos/bin/Realmd_Controller.sh
mv $INSTALL_DIR/mangos/mysql.service /lib/systemd/system/mysql.service
mv $INSTALL_DIR/mangos/realmd.service /lib/systemd/system/realmd.service
mv $INSTALL_DIR/mangos/mangosd.service /lib/systemd/system/mangosd.service
mv $INSTALL_DIR/mangos/wow $INSTALL_DIR/mangos/bin/wow
ln -s $INSTALL_DIR/mangos/bin/wow /usr/bin/wow
chmod -R 0777 $INSTALL_DIR/mangos/bin/wow
chmod -R 0777 $INSTALL_DIR/mangos/bin/Mangosd_Controller.sh
chmod -R 0777 $INSTALL_DIR/mangos/bin/Realmd_Controller.sh

sed -i "s/\/folder/$INSTALL_DIR_TEXT/g" $INSTALL_DIR/mangos/etc/mangosd.conf
sed -i "s/\/folder/$INSTALL_DIR_TEXT/g" $INSTALL_DIR/mangos/etc/realmd.conf
sed -i "s/\/folder/$INSTALL_DIR_TEXT/g" $INSTALL_DIR/mangos/bin/Mangosd_Controller.sh
sed -i "s/\/folder/$INSTALL_DIR_TEXT/g" $INSTALL_DIR/mangos/bin/Realmd_Controller.sh
sed -i "s/\/folder/$INSTALL_DIR_TEXT/g" /lib/systemd/system/mangosd.service
sed -i "s/\/folder/$INSTALL_DIR_TEXT/g" /lib/systemd/system/realmd.service
sed -i "s/\/folder/$INSTALL_DIR_TEXT/g" /lib/systemd/system/mysql.service

