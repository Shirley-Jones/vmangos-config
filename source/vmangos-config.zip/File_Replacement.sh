#!/bin/bash
File=$0
INSTALL_DIR=$1


sed -i "s/\/folder/$INSTALL_DIR/g" $INSTALL_DIR/mangos/etc/mangosd.conf
sed -i "s/\/folder/$INSTALL_DIR/g" $INSTALL_DIR/mangos/etc/realmd.conf
sed -i "s/\/folder/$INSTALL_DIR/g" $INSTALL_DIR/mangos/bin/Mangosd_Controller.sh
sed -i "s/\/folder/$INSTALL_DIR/g" $INSTALL_DIR/mangos/bin/Realmd_Controller.sh
sed -i "s/\/folder/$INSTALL_DIR/g" /lib/systemd/system/mangosd.service
sed -i "s/\/folder/$INSTALL_DIR/g" /lib/systemd/system/realmd.service
sed -i "s/\/folder/$INSTALL_DIR/g" /lib/systemd/system/mysql.service
return 0;
